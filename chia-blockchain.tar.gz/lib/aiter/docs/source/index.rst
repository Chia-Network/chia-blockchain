.. aiter documentation master file, created by
   sphinx-quickstart on Sun Feb 17 15:23:07 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to aiter's documentation!
=================================

.. image:: https://codecov.io/github/richardkiss/aiter/coverage.svg?branch=master
    :target: https://codecov.io/github/richardkiss/aiter

.. image:: https://img.shields.io/pypi/l/aiter.svg
    :target: https://pypi.python.org/pypi/aiter

.. image:: https://img.shields.io/pypi/pyversions/aiter.svg
    :target: https://pypi.python.org/pypi/aiter

.. image:: https://travis-ci.org/richardkiss/aiter.svg?branch=master
    :target: https://travis-ci.org/richardkiss/aiter

This documentation is a work-in-progress, and your contributions are welcome
at <https://github.com/richardkiss/aiter>.




.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: aiter
    :members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
