import unittest


class test_iter_to_aiter(unittest.TestCase):
    pass
