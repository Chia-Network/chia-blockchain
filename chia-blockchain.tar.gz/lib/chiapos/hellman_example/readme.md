# Hellman Example

This directory provides a plotting example which implements Hellman Attacks.
The PDF contains details on the theory of such attack.
The main purpose of it is to reduce the final plot size, by using more CPU and memory during plotting.

Please not that this code is experimental and may not work efficiently for larger plot sizes.
The standard reference implementation should used for comparison in the competition.